#################################################################
##           Practical 6 for GEOM184 - Open Source GIS         ##
##                      27/02/2025                             ##
##                  Creating a ShinyApp                        ##
##                        Global.R                             ##
##        code by Diego Panici (d.panici@exeter.ac.uk)         ##
#################################################################

#Reminder to Set Working directory

#percent clip to show all values for flow accumulation and slope
# Extract valid values
pct_clip <- function(raster_layer) {
  values_raster <- values(raster_layer)
  values_raster <- na.omit(values_raster)  
  
  lower_threshold <- quantile(values_raster, 0.05, na.rm = TRUE)
  upper_threshold <- quantile(values_raster, 0.95, na.rm = TRUE)
  
  raster_layer[raster_layer > upper_threshold] <- upper_threshold
  raster_layer[raster_layer < lower_threshold] <- lower_threshold
  
  return(raster_layer)
}


# G1 Load large wood, river, and bridge data ----
lw_points <- st_read("LW_Type.shp")
river <- st_read("RiverIsonzo.shp")
bridges <- st_read("BridgesIsonzo.shp")
clusters <- st_read("KmeanClustering.gpkg")
nearest <- st_read("DistanceToHub.gpkg")
heatmap <- rast("LW_Heatmap500km.tif")
flow <- rast("flowAcc.tif")
slope <- rast("Isonzo1kmbufferDTM.tif")
buffer <- st_read("oneKMBuffer.shp")
LW_catch <- st_read("largeWoodCatchers.shp")


#Loading Data
#Convert vectors to CRS 4326
lw_points <- st_transform(lw_points, crs = 4326)
river <- st_transform(river, crs = 4326)
bridges <- st_transform(bridges, crs = 4326)
clusters <- st_transform(clusters, crs = 4326)
nearest <- st_transform(nearest, crs = 4326)
buffer <- st_transform(buffer, crs = 4326)
LW_catch <- st_transform(LW_catch, crs = 4326)
heatmap <- project(heatmap, crs(river))
flow <- project(flow, crs(river))
slope <- project(slope, crs(river))

#slope <- crop(slope, buffer)
flow <- crop(flow, buffer)

# Using alpha band as no data for slope
slope_valid <- slope[[1]]  
slope_alpha <- slope[[2]]
values(slope)[values(slope_alpha) == 0] <- NA


# Dynamically generate colours based on number of unique clusters
num_clusters <- length(unique(clusters$CLUSTER_ID))
pal_clusters <- colorFactor(palette = colorRampPalette(brewer.pal(12, "Paired"))(num_clusters), domain = clusters$CLUSTER_ID)
pal_heatmap <- colorNumeric(palette = "inferno", domain = na.omit(values(heatmap)), na.color = "transparent")


flow <- pct_clip(flow)
slope <- pct_clip(slope)


pal_flow <- colorNumeric(palette = "YlGnBu", domain = na.omit(values(flow)), na.color = "transparent")
pal_slope <- colorNumeric(palette = "viridis", domain = na.omit(values(slope)), na.color = "transparent")