#################################################################
##           Practical 6 for GEOM184 - Open Source GIS         ##
##                      27/02/2025                             ##
##                  Creating a ShinyApp                        ##
##                        Global.R                             ##
##        code by Diego Panici (d.panici@exeter.ac.uk)         ##
#################################################################

#Reminder to Set Working directory

#percent clip function to show all values for flow accumulation and slope
pct_clip <- function(raster_layer) {
  values_raster <- values(raster_layer)
  values_raster <- na.omit(values_raster)  
  
  #0% and 95% thresholds to clip extreme values throwing the colour scheme out of control 
  lower_threshold <- quantile(values_raster, 0.00, na.rm = TRUE)
  upper_threshold <- quantile(values_raster, 0.95, na.rm = TRUE)
  
  raster_layer[raster_layer > upper_threshold] <- upper_threshold
  raster_layer[raster_layer < lower_threshold] <- lower_threshold
  
  return(raster_layer)
}


# G1 Load large wood, river, and bridge data ----
lw_points <- st_read("LW_Type.shp")
river <- st_read("RiverIsonzo.shp")
bridges <- st_read("BridgesIsonzo.shp")
clusters <- st_read("KmeanClustering.gpkg")
nearest <- st_read("DistanceToHub.gpkg")
heatmap <- rast("LW_Heatmap500km.tif")
flow <- rast("flowAcc.tif")
dtm <- rast("Isonzo1kmbufferDTM.tif")
buffer <- st_read("oneKMBuffer.shp")
LW_catch <- st_read("largeWoodCatchers.shp")


#Loading Data
#Convert data to CRS 4326
lw_points <- st_transform(lw_points, crs = 4326)
river <- st_transform(river, crs = 4326)
bridges <- st_transform(bridges, crs = 4326)
clusters <- st_transform(clusters, crs = 4326)
nearest <- st_transform(nearest, crs = 4326)

LW_catch <- st_transform(LW_catch, crs = 4326)
heatmap <- project(heatmap, crs(river))
flow <- project(flow, crs(river))
dtm <- project(dtm, crs(river))


# Using alpha band as no data for slope
dtm_valid <- dtm[[1]]  
dtm_alpha <- dtm[[2]]
values(dtm)[values(dtm_alpha) == 0] <- NA


# Dynamically generate colours based on number of unique clusters
num_clusters <- length(unique(clusters$CLUSTER_ID))
pal_clusters <- colorFactor(palette = colorRampPalette(brewer.pal(12, "Paired"))(num_clusters), domain = clusters$CLUSTER_ID)
pal_heatmap <- colorNumeric(palette = "inferno", domain = na.omit(values(heatmap)), na.color = "transparent")

#apply percent clip function
flow <- pct_clip(flow)
dtm <- pct_clip(dtm)


#setting colour range from 0 so  it is not treated as NA
range_flow <- range(0, values(flow), na.rm = TRUE)
range_dtm <- range(0, values(dtm), na.rm = TRUE)

#generate colours
pal_flow <- colorNumeric(palette = "YlGnBu", domain = range_flow, na.color = "transparent")
pal_dtm <- colorNumeric(palette = "viridis", domain = range_dtm, na.color = "transparent")

