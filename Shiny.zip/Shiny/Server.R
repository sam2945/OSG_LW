#################################################################
##           Practical 6 for GEOM184 - Open Source GIS         ##
##                      27/02/2025                             ##
##                  Creating a ShinyApp                        ##
##                       Server.R                              ##
##        code by Diego Panici (d.panici@exeter.ac.uk)         ##
#################################################################


# S1 Render leaflet map ----
# Leaflet map output
heatmap_raster <- raster(heatmap)
flow_raster <- raster(flow)
slope_raster <- raster(slope[[1]])

output$map <- renderLeaflet({
  leaflet() %>%
    setView(lng=13.533545, lat=45.850065, zoom=11.3) %>%
    addProviderTiles(providers$OpenStreetMap, group = "Colour") %>%
    addPolylines(data = river, color = "blue", weight = 2, opacity = 0.8, group = "River") %>%
    addPolylines(data = LW_catch, color = "pink", weight = 10, opacity = 1, group = "Large Wood Catchers") %>%
    addRasterImage(heatmap_raster, colors = pal_heatmap, opacity = 0.8, group = "Heatmap") %>%
    addRasterImage(flow_raster, colors = pal_flow, opacity = 0.8, group = "Flow Accumulation") %>%
    addRasterImage(slope_raster, colors = pal_slope, opacity = 0.8, group = "Slope") %>%
    addImageQuery(
      heatmap_raster,  # Use the raster object here
      layerId = "Heatmap",
      prefix = "Value: ",
      digits = 2,
      position = "topright",
      type = "mousemove",
      options = queryOptions(position = "topright"),
      group = "Heatmap"
    )%>%
    addLayersControl(
      baseGroups = c("Colour"),
      overlayGroups = c("River", "Distance to a Bridge", "Bridges", "Large Wood", "Heatmap", "Slope","Flow Accumulation", "Large Wood Catchers"),
      options = layersControlOptions(collapsed = FALSE)
    )%>%
    addLegend(position = "bottomright", 
            pal = pal_flow, values = na.omit(values(flow_raster)),
            title = "Flow Accumulation",
            opacity = 1) %>%
    addLegend(position = "bottomleft", 
              pal = pal_slope, values = na.omit(values(slope_raster)),
              title = "Slope", 
              opacity = 1)
})
observe({
  leafletProxy("map") %>%
    clearMarkers() %>%
    addCircleMarkers(data = clusters, fillColor = ~pal_clusters(CLUSTER_ID), color = "black", 
                     weight = 1, radius = 5, stroke = TRUE, fillOpacity = 0.7,
                     popup = ~paste("<b>Type:</b>", LW_Type, "<br><b>Imagery used:</b>", imgProv, "<br><b>Cluster ID:</b>", CLUSTER_ID),
                     group = "Large Wood") %>%
    addCircleMarkers(data = bridges, color = "purple", 
                     weight = 1, radius = 8, stroke = TRUE, fillOpacity = 0.7,
                     popup = ~paste("<b>Name:</b>", Name),
                     group = "Bridges") %>%
    addPolylines(data = nearest, color = 'black', 
                 weight = 3, stroke = TRUE, fillOpacity = 0.7,
                 popup = ~paste("<b>Distance to a Bridge:</b>", signif(HubDist, 1),"m","<br><b>Bridge:</b>", HubName ),
                 group = "Distance to a Bridge")
})







